export class CommonMsg {
    internal_error = {
        massege: " server error occurred please try again later"
    }
    created = {
        massege: "data saved successfully"
    }
}


export const CommonMessage = { 


    


}